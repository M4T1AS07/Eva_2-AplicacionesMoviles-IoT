package com.example.smartlightcontrol

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CompoundButton
import com.example.smartlightcontrol.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // SharedPreferences keys
    private val PREFS_NAME = "smart_light_prefs"
    private val KEY_IS_ON = "is_on"
    private val KEY_BRIGHTNESS = "brightness"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Cargar estado guardado
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isOn = prefs.getBoolean(KEY_IS_ON, false)
        val brightness = prefs.getInt(KEY_BRIGHTNESS, 50)

        // Inicializar UI
        binding.switchPower.isChecked = isOn
        binding.seekbarBrightness.progress = brightness
        updateUi(isOn, brightness)

        // Listeners
        binding.switchPower.setOnCheckedChangeListener { _: CompoundButton, checked: Boolean ->
            updateUi(checked, binding.seekbarBrightness.progress)
            saveState(checked, binding.seekbarBrightness.progress)
        }

        binding.seekbarBrightness.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                updateUi(binding.switchPower.isChecked, progress)
            }

            override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {
                saveState(binding.switchPower.isChecked, binding.seekbarBrightness.progress)
            }
        })

        binding.buttonToggle.setOnClickListener {
            val newState = !binding.switchPower.isChecked
            binding.switchPower.isChecked = newState
            updateUi(newState, binding.seekbarBrightness.progress)
            saveState(newState, binding.seekbarBrightness.progress)
        }

        binding.buttonReset.setOnClickListener {
            binding.switchPower.isChecked = false
            binding.seekbarBrightness.progress = 50
            updateUi(false, 50)
            saveState(false, 50)
        }
    }

    private fun updateUi(isOn: Boolean, brightness: Int) {
        if (isOn) {
            binding.textStatus.text = "Encendida"
            // Simula brillo mostrando porcentaje y cambiando alpha de la vista
            binding.textBrightness.text = "Brillo: $brightness%"
            val alpha = 0.2f + (brightness / 100f) * 0.8f // entre 0.2 y 1.0
            binding.lightPreview.alpha = alpha
        } else {
            binding.textStatus.text = "Apagada"
            binding.textBrightness.text = "Brillo: 0%"
            binding.lightPreview.alpha = 0.1f
        }
    }

    private fun saveState(isOn: Boolean, brightness: Int) {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_IS_ON, isOn).putInt(KEY_BRIGHTNESS, brightness).apply()
    }
}
